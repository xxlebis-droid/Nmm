const admin = require('firebase-admin');
const crypto = require('crypto');
class HttpsError extends Error { constructor(c, m) { super(m); this.code = c; } }
admin.initializeApp({ credential: admin.credential.cert(JSON.parse(Buffer.from(process.env.FIREBASE_SA_B64, 'base64').toString())) });
const db = admin.firestore();
const FV = admin.firestore.FieldValue;
const BOT = { value: () => process.env.BOT_TOKEN }, ADMIN = { value: () => process.env.ADMIN_ID }, HOOK = { value: () => process.env.WEBHOOK_SECRET };

// ===== НАСТРОЙКИ =====
const DAILY = [[5, 30], [10, 25], [15, 15], [25, 12], [50, 9], [75, 5], [100, 3], [100000, 1]]; // [звёзды, шанс %] (сумма = 100)
const MULTS = [1.5, 2, 3, 5, 10, 20];   // доступные множители апгрейда
const EDGE = 95;                        // шанс апгрейда = 95 / множитель (%)
const BET_MS = 8000, PAUSE_MS = 3500;   // краш: время ставок и пауза после взрыва
// Краш: 55% до 1.5x, 35% до 2x, 10% до 3x (максимум 3x)
const CRASH = [[0.55, 1, 1.5], [0.35, 1.5, 2], [0.10, 2, 3]];
// =====================

const rnd = () => crypto.randomInt(0, 1e6) / 1e6;
const mult = t => 1 + 0.1 * t + 0.01 * t * t;
const tOf = m => (-0.1 + Math.sqrt(0.01 + 0.04 * (m - 1))) / 0.02;
const err = (m) => new HttpsError('failed-precondition', m);

function genPoint() {
  let r = rnd();
  for (const [p, a, b] of CRASH) { if (r < p) return Math.floor((a + rnd() * (b - a)) * 100) / 100; r -= p; }
  return 1.2;
}
function pickDaily() {
  let r = crypto.randomInt(0, 100);
  for (const [p, w] of DAILY) { if (r < w) return p; r -= w; }
  return 5;
}
function verify(initData) {
  const p = new URLSearchParams(initData || '');
  const hash = p.get('hash'); p.delete('hash');
  const s = [...p.entries()].map(([k, v]) => k + '=' + v).sort().join('\n');
  const key = crypto.createHmac('sha256', 'WebAppData').update(BOT.value()).digest();
  const h = crypto.createHmac('sha256', key).update(s).digest('hex');
  if (!hash || h !== hash || Date.now() / 1000 - Number(p.get('auth_date')) > 86400)
    throw new HttpsError('unauthenticated', 'Откройте приложение через Telegram');
  return JSON.parse(p.get('user'));
}
const pub = (id, d) => ({ id, stars: d.stars || 0, nextDaily: (d.lastDaily || 0) + 864e5, name: d.name, photo: d.photo });
const tgSend = (chat, text) => fetch(`https://api.telegram.org/bot${BOT.value()}/sendMessage`, {
  method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: chat, text })
}).catch(() => {});

// транзакция над пользователем: fn сначала читает, потом пишет
function withUser(u, fn) {
  const id = String(u.id), ref = db.doc('users/' + id);
  return db.runTransaction(async tx => {
    const s = await tx.get(ref);
    const d = s.exists ? s.data() : { stars: 0, lastDaily: 0 };
    d.name = [u.first_name, u.last_name].filter(Boolean).join(' ') || 'Игрок';
    d.username = u.username || ''; d.photo = u.photo_url || '';
    const out = (await fn(tx, d, id)) || {};
    tx.set(ref, d);
    return { ...out, user: pub(id, d) };
  });
}
const intIn = (v, min, max) => { v = Math.floor(Number(v)); if (!(v >= min && v <= max)) throw err('Неверная сумма'); return v; };

async function crashPoll() {
  return db.runTransaction(async tx => {
    const sref = db.doc('crash/state'), kref = db.doc('crashSecret/cur');
    const [s, k] = await Promise.all([tx.get(sref), tx.get(kref)]);
    const now = Date.now(); const st = s.exists ? s.data() : null;
    if (!st || (st.phase === 'crashed' && now >= st.nextAt)) {
      const id = (st ? st.id : 0) + 1;
      tx.set(kref, { id, point: genPoint() });
      tx.set(sref, { id, phase: 'bet', betEnd: now + BET_MS, flyStart: now + BET_MS, hist: st ? st.hist : [] });
    } else if (st.phase !== 'crashed' && now >= st.flyStart + tOf(k.data().point) * 1000) {
      const point = k.data().point;
      tx.set(sref, { ...st, phase: 'crashed', crashPoint: point, nextAt: now + PAUSE_MS, hist: [point, ...(st.hist || [])].slice(0, 12) });
    }
    return { now };
  });
}

const apiFn = async req => {
  const { action, initData } = req.data || {};
  if (action === 'crashPoll') return crashPoll();
  const u = verify(initData); const now = Date.now(); const D = req.data;
  let out;

  if (action === 'me') out = await withUser(u, () => ({}));

  else if (action === 'daily') out = await withUser(u, (tx, d) => {
    if (now < (d.lastDaily || 0) + 864e5) throw err('Кейс уже открыт сегодня');
    const prize = pickDaily(); d.stars = (d.stars || 0) + prize; d.lastDaily = now; return { prize };
  });

  else if (action === 'promo') {
    const code = String(D.code || '').trim().toUpperCase().slice(0, 32);
    if (!/^[A-Z0-9_-]+$/.test(code)) throw err('Неверный промокод');
    out = await withUser(u, async (tx, d, id) => {
      const pref = db.doc('promos/' + code), uref = db.doc(`promos/${code}/used/${id}`);
      const [p, used] = await Promise.all([tx.get(pref), tx.get(uref)]);
      if (!p.exists) throw err('Промокод не найден');
      const pd = p.data();
      if (used.exists) throw err('Вы уже использовали этот промокод');
      if (pd.maxUses && (pd.uses || 0) >= pd.maxUses) throw err('Промокод закончился');
      tx.update(pref, { uses: FV.increment(1) }); tx.set(uref, { t: now });
      d.stars = (d.stars || 0) + pd.stars; return { got: pd.stars };
    });
  }

  else if (action === 'upgrade') out = await withUser(u, (tx, d) => {
    const mult_ = Number(D.mult); if (!MULTS.includes(mult_)) throw err('Неверный множитель');
    const amount = intIn(D.amount, 1, d.stars || 0);
    const chance = EDGE / mult_, roll = crypto.randomInt(0, 100000) / 1000, win = roll < chance;
    d.stars -= amount; if (win) d.stars += Math.floor(amount * mult_);
    return { win, roll, chance };
  });

  else if (action === 'withdraw') {
    const nick = String(D.nick || '').trim().slice(0, 64); if (!nick) throw err('Введите юзернейм');
    out = await withUser(u, (tx, d, id) => {
      const amount = d.stars || 0; if (amount < 1) throw err('Нет звёзд для вывода');
      d.stars = 0;
      tx.set(db.collection('withdrawals').doc(), { uid: id, tg: d.username, nick, amount, t: now, status: 'new' });
      return { msg: `💸 Заявка на вывод\nTelegram: ${d.name} @${d.username || '-'} (id ${id})\nDevoGram: ${nick}\nЗвёзд: ${amount}\n\nЕсли отказ: /give ${id} ${amount}` };
    });
    await tgSend(ADMIN.value().trim(), out.msg); delete out.msg;
  }

  else if (action === 'crashBet') out = await withUser(u, async (tx, d, id) => {
    const s = await tx.get(db.doc('crash/state')); const st = s.data();
    if (!st || st.phase !== 'bet' || now >= st.betEnd) throw err('Ставки закрыты');
    const bref = db.doc(`crashBets/${st.id}_${id}`);
    if ((await tx.get(bref)).exists) throw err('Ставка уже сделана');
    const amount = intIn(D.amount, 1, d.stars || 0);
    d.stars -= amount;
    tx.set(bref, { rid: st.id, uid: id, name: d.name, photo: d.photo, amount, cash: null });
  });

  else if (action === 'crashCash') out = await withUser(u, async (tx, d, id) => {
    const [s, k] = await Promise.all([tx.get(db.doc('crash/state')), tx.get(db.doc('crashSecret/cur'))]);
    const st = s.data(); if (!st) throw err('Нет раунда');
    const bref = db.doc(`crashBets/${st.id}_${id}`); const b = await tx.get(bref);
    if (!b.exists || b.data().cash) throw err('Нет активной ставки');
    const point = k.data().point;
    if (st.phase !== 'bet' || now < st.flyStart || now >= st.flyStart + tOf(point) * 1000) throw err('Ракета уже улетела');
    const m = Math.min(Math.floor(mult((now - st.flyStart) / 1000) * 100) / 100, point);
    const win = Math.floor(b.data().amount * m);
    d.stars += win; tx.update(bref, { cash: m }); return { win, m };
  });

  else throw err('Неизвестное действие');
  return out;
};

// Бот: админ-команды /give /take /promo
const botFn = async (req, res) => {
  if (req.get('x-telegram-bot-api-secret-token') !== HOOK.value().trim()) return res.sendStatus(403);
  const m = req.body && req.body.message;
  if (m && m.text && String(m.from.id) === ADMIN.value().trim()) {
    const [c, a, b, e] = m.text.trim().split(/\s+/);
    try {
      if (c === '/give' || c === '/take') {
        const n = parseInt(b) * (c === '/take' ? -1 : 1); if (!a || isNaN(n)) throw new Error('формат: /give ID 500');
        await db.doc('users/' + a).set({ stars: FV.increment(n) }, { merge: true }); await tgSend(m.chat.id, 'Готово ✅');
      } else if (c === '/promo') {
        if (!a || isNaN(parseInt(b))) throw new Error('формат: /promo КОД 50 100');
        await db.doc('promos/' + a.toUpperCase()).set({ stars: parseInt(b), maxUses: parseInt(e) || 0, uses: 0 });
        await tgSend(m.chat.id, `Промокод ${a.toUpperCase()}: ${b} ⭐, активаций: ${parseInt(e) || '∞'}`);
      } else await tgSend(m.chat.id, '/give ID N\n/take ID N\n/promo КОД ЗВЁЗДЫ АКТИВАЦИИ');
    } catch (x) { await tgSend(m.chat.id, 'Ошибка: ' + x.message); }
  }
  res.sendStatus(200);
};

module.exports = async (req, res) => {
  if (req.query && req.query.bot) return botFn(req, res);
  try { res.status(200).json(await apiFn({ data: req.body || {} })); }
  catch (e) {
    if (e instanceof HttpsError) return res.status(400).json({ error: e.message });
    console.error(e); res.status(500).json({ error: 'Ошибка сервера' });
  }
};
